<?php
include 'db.php';
$result = mysqli_query($conn, "SELECT * FROM bookings");
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>تفاصيل الحجوزات</title>
    <style>
        body {
            font-family: Arial;
            direction: rtl;
            background-color: #f4f4f4;
        }

        table {
            width: 95%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: #fff;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #003366;
            color: white;
        }

        h2 {
            text-align: center;
            margin-top: 30px;
            color: #003366;
        }
    </style>
</head>
<body>
    <h2>تفاصيل الحجوزات</h2>
    <table>
        <tr>
            <th>الاسم الكامل</th>
            <th>البريد الإلكتروني</th>
            <th>رقم الهاتف</th>
            <th>رقم الجواز</th>
            <th>الوجهة</th>
            <th>عدد الأفراد</th>
            <th>نوع التذكرة</th>
            <th>الدرجة</th>
            <th>السعر</th>
            <th>تاريخ الحجز</th>
        </tr>

        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
            <tr>
                <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                <td><?php echo htmlspecialchars($row['email']); ?></td>
                <td><?php echo htmlspecialchars($row['phone']); ?></td>
                <td><?php echo htmlspecialchars($row['passport_number']); ?></td>
                <td><?php echo htmlspecialchars($row['to_city']); ?></td>
                <td><?php echo $row['people_count']; ?></td>
                <td><?php echo htmlspecialchars($row['ticket_type']); ?></td>
                <td><?php echo htmlspecialchars($row['class']); ?></td>
                <td>$ <?php echo number_format($row['price'], 2); ?></td>
                <td><?php echo $row['created_at']; ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>