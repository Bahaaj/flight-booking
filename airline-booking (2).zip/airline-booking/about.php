 
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>من نحن</title>
    <link rel="stylesheet" href="css/about.css">
</head>
<body>

    <div class="navbar">
        <div class="logo">نظام حجز الطيران</div>
        <ul class="nav-links">
            <li><a href="index.php">الرئيسية</a></li>
            <li><a href="about.php">من نحن</a></li>
            <li><a href="flights.php">الرحلات</a></li>
            <li><a href="contact.php">اتصل بنا</a></li>
            <li><a href="complaints.php">شكاوي واقتراحات</a></li>
        </ul>
    </div>

    <div class="about">
        <h2>من نحن</h2>
        <p>نحن شركة طيران متخصصة في تقديم خدمات السفر الجوية بأعلى جودة، نهدف إلى توفير رحلات مريحة وآمنة للمسافرين إلى وجهات متعددة حول العالم. نحن نؤمن بتقديم تجربة سفر استثنائية ونحترم خصوصية عملائنا.</p>
        <p>يتم تشغيل كل رحلة بأعلى معايير الأمان مع تقديم خدمة عملاء على مدار الساعة للرد على استفسارات المسافرين.</p>
    </div>

</body>
</html>
