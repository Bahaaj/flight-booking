<?php
include 'db.php';

// عدد الرحلات
$res1 = mysqli_query($conn, "SELECT COUNT(*) AS total FROM flights");
$flights_count = $res1 ? mysqli_fetch_assoc($res1)['total'] : 0;

// عدد الحجوزات
$res2 = mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings");
$bookings_count = $res2 ? mysqli_fetch_assoc($res2)['total'] : 0;

// إجمالي الأرباح
$res3 = mysqli_query($conn, "SELECT IFNULL(SUM(total_price), 0) AS total FROM bookings");
$earnings = $res3 ? mysqli_fetch_assoc($res3)['total'] : 0;

// جلب الرحلات
$flights = mysqli_query($conn, "SELECT * FROM flights ORDER BY id ASC");
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>لوحة تحكم الأدمن</title>
    <style>
        body {
            font-family: Tahoma;
            direction: rtl;
            background-color: #f4f6f9;
            padding: 30px;
        }

        h1 {
            text-align: center;
            color: #003366;
            margin-bottom: 30px;
        }

        .stats {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            flex: 1;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .card h3 {
            margin-bottom: 10px;
            color: #003366;
        }

        .card p {
            font-size: 24px;
            font-weight: bold;
            color: #007bff;
        }

        .card a.btn {
            margin-top: 10px;
            display: inline-block;
            background-color: #007bff;
            color: white;
            padding: 6px 12px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
        }

        .card a.btn:hover {
            background-color: #0056b3;
        }

        a.add-btn {
            display: inline-block;
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            margin-bottom: 20px;
        }

        a.add-btn:hover {
            background-color: #218838;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #003366;
            color: white;
        }

        a.btn-action {
            padding: 5px 10px;
            border-radius: 4px;
            text-decoration: none;
            color: white;
            font-size: 14px;
        }

        a.edit {
            background-color: #17a2b8;
        }

        a.edit:hover {
            background-color: #138496;
        }

        a.delete {
            background-color: #dc3545;
        }

        a.delete:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>

<h1>لوحة إدارة الرحلات ✈</h1>

<div class="stats">
    <div class="card">
        <h3>عدد الرحلات</h3>
        <p><?= $flights_count ?></p>
    </div>
    <div class="card">
        <h3>عدد الحجوزات</h3>
        <p><?= $bookings_count ?></p>
        <a href="view_bookings.php" class="btn">عرض التفاصيل</a>
    </div>
    <div class="card">
        <h3>إجمالي الأرباح</h3>
        <p><?= number_format($earnings, 2) ?> $</p>
    </div>
</div>

<div style="text-align: center;">
    <a href="add_flight.php" class="add-btn">➕ إضافة رحلة جديدة</a>
</div>

<table>
    <thead>
        <tr>
            <th>تسلسل</th>
            <th>من</th>
            <th>إلى</th>
            <th>تاريخ المغادرة</th>
            <th>تاريخ العودة</th>
            <th>السعر</th>
            <th>تعديل</th>
            <th>حذف</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($flights && mysqli_num_rows($flights) > 0): ?>
            <?php $i = 1; while ($row = mysqli_fetch_assoc($flights)): ?>
                <tr>
                    <td><?= $i++ ?></td>
                    <td><?= $row['from_city'] ?></td>
                    <td><?= $row['to_city'] ?></td>
                    <td><?= $row['departure_date'] ?></td>
                    <td><?= $row['return_date'] ?? '-' ?></td>
                    <td><?= number_format($row['price'], 2) ?> $</td>
                    <td><a href="edit_flight.php?id=<?= $row['id'] ?>" class="btn-action edit">تعديل</a></td>
                    <td><a href="delete_flight.php?id=<?= $row['id'] ?>" class="btn-action delete" onclick="return confirm('هل أنت متأكد من حذف هذه الرحلة؟')">حذف</a></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="8">لا توجد رحلات مسجلة</td></tr>
        <?php endif; ?>
    </tbody>
</table>

</body>
</html>