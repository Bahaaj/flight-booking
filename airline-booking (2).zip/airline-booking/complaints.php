<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>الشكاوي والاقتراحات</title>
    <link rel="stylesheet" href="css/complaints.css">
</head>
<body>

    <div class="navbar">
        <div class="logo">نظام حجز الطيران</div>
        <ul class="nav-links">
            <li><a href="index.php">الرئيسية</a></li>
            <li><a href="about.php">من نحن</a></li>
            <li><a href="flights.php">الرحلات</a></li>
            <li><a href="contact.php">اتصل بنا</a></li>
            <li><a href="complaints.php">شكاوي واقتراحات</a></li>
        </ul>
    </div>

    <div class="complaints">
        <h2>الشكاوي والاقتراحات</h2>

        <!-- Notification message -->
        <div id="notification" style="display:none; padding: 10px; background-color: #4CAF50; color: white; margin-bottom: 20px;">
            تم إرسال الشكوى/الاقتراح بنجاح!
        </div>

        <form action="submit_complaints.php" method="POST" id="complaintForm">
            <label for="complaint_type">نوع الشكوى/الاقتراح:</label>
            <select id="complaint_type" name="complaint_type">
                <option value="complaint">شكوى</option>
                <option value="suggestion">اقتراح</option>
            </select>

            <label for="message">الرسالة:</label>
            <textarea id="message" name="message" rows="5" required></textarea>

            <button type="submit">إرسال</button>
        </form>
    </div>

    <script>
        document.getElementById('complaintForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show success message
            document.getElementById('notification').style.display = 'block';

            // Reset form after submission
            setTimeout(function() {
                document.getElementById('complaintForm').reset();
            }, 3000);
        });
    </script>

</body>
</html>
