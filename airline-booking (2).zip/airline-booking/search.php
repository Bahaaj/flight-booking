 <!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>بحث الرحلات</title>
    <link rel="stylesheet" href="\css\style.css">
   
</head>
<body>

    <div class="navbar">
        <div class="logo">نظام حجز الطيران</div>
        <ul class="nav-links">
            <li><a href="index.php">الرئيسية</a></li>
            <li><a href="about.php">من نحن</a></li>
            <li><a href="flights.php">الرحلات</a></li>
            <li><a href="contact.php">اتصل بنا</a></li>
            <li><a href="complaints.php">شكاوي واقتراحات</a></li>
        </ul>
    </div>

    <div class="search">
        <h2>بحث الرحلات</h2>
        <form action="search_results.php" method="POST">
            <label for="from">من:</label>
            <input type="text" id="from" name="from" placeholder="المدينة/الدولة" required>

            <label for="to">إلى:</label>
            <input type="text" id="to" name="to" placeholder="المدينة/الدولة" required>

            <label for="departure_date">تاريخ المغادرة:</label>
            <input type="date" id="departure_date" name="departure_date" required>

            <label for="return_date">تاريخ العودة (اختياري):</label>
            <input type="date" id="return_date" name="return_date">

            <button type="submit">بحث</button>
        </form>
    </div>

</body>
</html>

