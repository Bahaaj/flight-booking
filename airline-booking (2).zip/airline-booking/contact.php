<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>اتصل بنا</title>
    <link rel="stylesheet" href="css/contact-style.css">
</head>
<body>

    <!-- القائمة العلوية -->
    <div class="navbar">
        <div class="logo">نظام حجز الطيران</div>
        <ul class="nav-links">
            <li><a href="index.php">الرئيسية</a></li>
            <li><a href="about.php">من نحن</a></li>
            <li><a href="flights.php">الرحلات</a></li>
            <li><a href="contact.php">اتصل بنا</a></li>
            <li><a href="complaints.php">شكاوي واقتراحات</a></li>
        </ul>
    </div>

    <!-- نموذج اتصل بنا -->
    <div class="contact">
        <h2>اتصل بنا</h2>
        <form id="contactForm">
            <label for="name">الاسم:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">البريد الإلكتروني:</label>
            <input type="email" id="email" name="email" required>

            <label for="message">الرسالة:</label>
            <textarea id="message" name="message" rows="5" required></textarea>

            <button type="submit">إرسال</button>
        </form>
        <div class="alert" id="successMessage">تم إرسال الرسالة بنجاح! سيتم التواصل معك قريبًا.</div>
    </div>

    <script>
        document.getElementById('contactForm').addEventListener('submit', function(event) {
            event.preventDefault(); // منع الإرسال الفعلي
            document.getElementById('successMessage').style.display = 'block'; // عرض الرسالة
            this.reset(); // إعادة تعيين النموذج
        });
    </script>

</body>
</html>
