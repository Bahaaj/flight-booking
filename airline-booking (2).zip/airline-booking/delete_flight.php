<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // نفذ أمر الحذف
    $deleteQuery = "DELETE FROM flights WHERE id = $id";

    if (mysqli_query($conn, $deleteQuery)) {
        // إعادة التوجيه بعد الحذف
        header("Location: admin_dashboard.php?deleted=1");
        exit();
    } else {
        echo "فشل في الحذف: " . mysqli_error($conn);
    }
} else {
    echo "معرّف الرحلة غير موجود.";
}
?>