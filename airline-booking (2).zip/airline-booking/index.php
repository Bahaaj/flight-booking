<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>موقع حجز تذاكر الطيران</title>
    <!-- تضمين أيقونات Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            direction: rtl;
            background-color: #f5f5f5;
        }

        .navbar {
            background-color: #003366;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        .nav-links {
            list-style: none;
            display: flex;
            gap: 20px;
        }

        .nav-links li a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .nav-links li a i {
            margin-left: 6px;
        }

        .nav-links li a:hover {
            color: #ffcc00;
        }

        .hero {
            background-image: url('https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExNDd4cXFobzk3NXp6dDVtY2Nmbzk3cWs4dXRpNmhicGoxcmo1NzA2MyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/kzqtze9r4C3wnjCRM4/giphy.gif');
            background-size: cover;
            background-position: center;
            height: 100vh;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: white;
        }

        .hero::after {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            top: 0;
            left: 0;
        }

        .hero-content {
            position: relative;
            z-index: 2;
            animation: fadeInUp 1.5s ease-in-out;
        }

        .hero h2 {
            font-size: 48px;
            margin-bottom: 10px;
        }

        .hero p {
            font-size: 20px;
            margin-bottom: 25px;
        }

        .search-form {
            display: flex;
            flex-direction: column;
            gap: 10px;
            align-items: center;
        }

        .search-form input,
        .search-form select,
        .search-form button {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
        }

        .search-form input,
        .search-form select {
            width: 250px;
        }

        .search-form button {
            background-color: #ffcc00;
            color: #003366;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .search-form button:hover {
            background-color: #e6b800;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

    <!-- شريط التنقل -->
    <header>
        <nav class="navbar">
            <h1 class="logo"><i class="fas fa-plane-departure"></i> FlyNow</h1>
            <ul class="nav-links">
                <li><a href="index.php"><i class="fas fa-home"></i> الرئيسية</a></li>
                <li><a href="about.php"><i class="fas fa-users"></i> من نحن</a></li>
                <li><a href="flights.php"><i class="fas fa-plane"></i> الرحلات</a></li>
                <li><a href="contact.php"><i class="fas fa-phone"></i> اتصل بنا</a></li>
                <li><a href="suggestions.php"><i class="fas fa-comment-dots"></i> الشكاوى والاقتراحات</a></li>
            </ul>
        </nav>
    </header>

    <!-- الخلفية الرئيسية -->
    <section class="hero">
        <div class="hero-content">
            <h2>اكتشف العالم معنا!</h2>
            <p>احجز رحلتك بكل سهولة وسرعة</p>

            <!-- نموذج البحث -->
            <form action="flights.php" method="GET" class="search-form">
                <input type="text" name="from" placeholder="من (مثلاً: عمان)" required>
                <input type="text" name="to" placeholder="إلى (مثلاً: إسطنبول)" required>
                <select name="type">
                    <option value="ذهاب">ذهاب فقط</option>
                    <option value="ذهاب وعودة">ذهاب وعودة</option>
                </select>
                <button type="submit">بحث</button>
            </form>
        </div>
    </section>

</body>
</html>