<?php
include 'db.php';

$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $flight_id = $_POST['flight_id'];
    $to = $_POST['to'];
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $passport_number = $_POST['passport_number'];
    $class = $_POST['class'];
    $baggage = $_POST['baggage'];
    $ticket_type = $_POST['ticket_type'];
    $seat = $_POST['seat'];
    $people_count = $_POST['people_count'];

    $price = ($ticket_type === 'round_trip') ? 150 * $people_count : 100 * $people_count;

    $stmt = $conn->prepare("INSERT INTO bookings (flight_id, to_city, full_name, email, phone, passport_number, class, baggage, ticket_type, seat, people_count, price)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param("ssssssssssid", $flight_id, $to, $full_name, $email, $phone, $passport_number, $class, $baggage, $ticket_type, $seat, $people_count, $price);

    if ($stmt->execute()) {
        $success = true;
        header("refresh:3;url=flights.php");
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>تفاصيل الرحلة</title>
    <style>
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            padding: 0;
            direction: rtl;
        }

        .container {
            width: 90%;
            max-width: 700px;
            margin: 40px auto;
            background-color: #ffffff;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
            padding: 30px;
            border-radius: 12px;
        }

        h2 {
            text-align: center;
            color: #003366;
            margin-bottom: 25px;
        }

        .success {
            background-color: #dff0d8;
            color: #3c763d;
            font-weight: bold;
            text-align: center;
            padding: 15px;
            margin-bottom: 25px;
            border-radius: 8px;
            border: 1px solid #c3e6cb;
        }

        form {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        input, select {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 6px;
            width: 100%;
            box-sizing: border-box;
        }

        button {
            grid-column: span 2;
            padding: 12px;
            background-color: #003366;
            color: white;
            font-size: 18px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0055aa;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>تفاصيل الرحلة</h2>

    <?php if ($success): ?>
        <div class="success">✅ تم الحجز بنجاح! <br> سيتم تحويلك إلى صفحة الرحلات خلال لحظات...</div>
    <?php endif; ?>

    <form method="POST">
        <input type="hidden" name="flight_id" value="<?php echo $_GET['flight_id']; ?>">
        <input type="hidden" name="to" value="<?php echo $_GET['to']; ?>">

        <input type="text" name="full_name" placeholder="الاسم الكامل" required>
        <input type="email" name="email" placeholder="البريد الإلكتروني" required>
        <input type="text" name="phone" placeholder="رقم الهاتف" required>
        <input type="text" name="passport_number" placeholder="رقم الجواز" required>

        <select name="class" required>
            <option value="">اختر الدرجة</option>
            <option value="economy">الاقتصادية</option>
            <option value="business">رجال أعمال</option>
            <option value="first">الدرجة الأولى</option>
        </select>

       <select name="baggage" required>
            <option value="">عدد الحقائب</option>
            <option value="1">1 حقيبة</option>
            <option value="2">2 حقيبة</option>
            <option value="3">3 حقيبة</option>
        </select>

        <select name="ticket_type" required>
            <option value="">نوع التذكرة</option>
            <option value="one_way">ذهاب فقط</option>
            <option value="round_trip">ذهاب وعودة</option>
        </select>

        <select name="seat" required>
            <option value="">اختيار المقعد</option>
            <option value="window">جانب النافذة</option>
            <option value="aisle">جانب الممر</option>
            <option value="middle">منتصف</option>
        </select>

        <input type="number" name="people_count" min="1" placeholder="عدد الأفراد" required>

        <button type="submit">تأكيد الحجز</button>
    </form>
</div>

</body>
</html>