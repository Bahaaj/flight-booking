<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = "SELECT * FROM flights WHERE id = $id";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $flight = mysqli_fetch_assoc($result);
    } else {
        die("الرحلة غير موجودة.");
    }
} else {
    die("رقم الرحلة غير محدد.");
}

// تحديث الرحلة عند الضغط على زر "حفظ"
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $flight_number = $_POST['flight_number'];
    $from_city = $_POST['from_city'];
    $to_city = $_POST['to_city'];
    $departure_date = $_POST['departure_date'];
    $return_date = $_POST['return_date'];
    $price = $_POST['price'];

    $updateQuery = "UPDATE flights SET 
        flight_number='$flight_number',
        from_city='$from_city',
        to_city='$to_city',
        departure_date='$departure_date',
        return_date='$return_date',
        price='$price'
        WHERE id=$id";

    if (mysqli_query($conn, $updateQuery)) {
        echo "<script>alert('تم تحديث الرحلة بنجاح'); window.location.href='admin_dashboard.php';</script>";
    } else {
        echo "خطأ: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>تعديل الرحلة</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background-color: #f4f4f4;
            padding: 30px;
            text-align: center;
        }

        form {
            background-color: white;
            display: inline-block;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 300px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin: 8px 0;
            font-size: 14px;
        }

        button {
            padding: 10px 20px;
            background-color: #0078d7;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #005ea2;
        }
    </style>
</head>
<body>

    <h2>تعديل الرحلة</h2>

    <form method="POST">
        <input type="text" name="flight_number" value="<?php echo $flight['flight_number']; ?>" required>
        <input type="text" name="from_city" value="<?php echo $flight['from_city']; ?>" required>
        <input type="text" name="to_city" value="<?php echo $flight['to_city']; ?>" required>
        <input type="date" name="departure_date" value="<?php echo $flight['departure_date']; ?>" required>
        <input type="date" name="return_date" value="<?php echo $flight['return_date']; ?>">
        <input type="number" name="price" step="0.01" value="<?php echo $flight['price']; ?>" required>
        <button type="submit">حفظ التعديلات</button>
    </form>

</body>
</html>