<?php
include 'db.php'; // الاتصال بقاعدة البيانات
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>الرحلات</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="navbar">
    <div class="logo">نظام حجز الطيران</div>
    <ul class="nav-links">
        <li><a href="index.php">الرئيسية</a></li>
        <li><a href="about.php">من نحن</a></li>
        <li><a href="flights.php">الرحلات</a></li>
        <li><a href="contact.php">اتصل بنا</a></li>
        <li><a href="complaints.php">شكاوي واقتراحات</a></li>
    </ul>
</div>

<div style="padding: 40px;">
    <h2 style="text-align: center; margin-bottom: 30px;">الرحلات المتوفرة</h2>
    <div style="display: flex; flex-wrap: wrap; gap: 20px; justify-content: center;">
        <?php
        $sql = "SELECT * FROM flights ORDER BY departure_date ASC";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '
                <div style="width: 300px; padding: 20px; background-color: #fff; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
                    <h3 style="color: #003366;">' . $row["flight_number"] . '</h3>
                    <p><strong>من:</strong> ' . $row["from_city"] . '</p>
                    <p><strong>إلى:</strong> ' . $row["to_city"] . '</p>
                    <p><strong>تاريخ الرحلة:</strong> ' . $row["departure_date"] . '</p>
                    <a href="flight_details.php?flight_id=' . $row["id"] . '&to=' . urlencode($row["to_city"]) . '" style="display: inline-block; margin-top: 10px; background-color: #003366; color: white; padding: 10px 15px; border-radius: 5px; text-decoration: none;">التفاصيل والحجز</a>
                </div>';
            }
        } else {
            echo "<p>لا توجد رحلات حالياً.</p>";
        }
        ?>
    </div>
</div>

</body>
</html>