<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $flight_number = $_POST['flight_number'];
    $from = $_POST['from_city'];
    $to = $_POST['to_city'];
    $departure_date = $_POST['departure_date'];
    $return_date = $_POST['return_date']; // جديد
    $price = $_POST['price'];

    $stmt = mysqli_prepare($conn, "INSERT INTO flights (flight_number, from_city, to_city, departure_date, return_date, price) VALUES (?, ?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "sssssd", $flight_number, $from, $to, $departure_date, $return_date, $price);
    mysqli_stmt_execute($stmt);

    header("Location: admin_dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>إضافة رحلة جديدة</title>
    <style>
        body {
            font-family: Tahoma;
            direction: rtl;
            background-color: #f4f4f4;
            padding: 40px;
        }
        .form-box {
            width: 400px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #003366;
        }
        input, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        button {
            background-color: #28a745;
            color: white;
            font-weight: bold;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

<div class="form-box">
    <h2>إضافة رحلة جديدة</h2>
    <form method="POST">
        <input type="text" name="flight_number" placeholder="رقم الرحلة" required>
        <input type="text" name="from_city" placeholder="من" required>
        <input type="text" name="to_city" placeholder="إلى" required>
        <input type="date" name="departure_date" required>
        <input type="date" name="return_date"> <!-- جديد -->
        <input type="number" name="price" placeholder="السعر" step="0.01" required>
        <button type="submit">إضافة الرحلة</button>
    </form>
</div>

</body>
</html>